const connection = require('../db');

const Order = {
  create(orderData, cb) {
    const sql = 'INSERT INTO orders (userId, orderDate, totalAmount, status) VALUES (?, ?, ?, ?)';
    connection.query(sql, [orderData.userId, orderData.orderDate, orderData.totalAmount, orderData.status], cb);
  },

  addItems(orderId, items, cb) {
    if (!Array.isArray(items) || items.length === 0) return cb(null, { affectedRows: 0 });
    let done = 0;
    let errs = [];
    items.forEach(item => {
      const sql = 'INSERT INTO order_items (orderId, productId, quantity, price) VALUES (?, ?, ?, ?)';
      connection.query(sql, [orderId, item.productId || item.id, item.quantity, item.price], (err, res) => {
        if (err) errs.push(err);
        done++;
        if (done === items.length) {
          if (errs.length) return cb(errs[0]);
          return cb(null, { inserted: done });
        }
      });
    });
  },

  getById(id, cb) {
    const sql = 'SELECT * FROM orders WHERE id = ?';
    connection.query(sql, [id], (err, results) => {
      if (err) return cb(err);
      cb(null, results[0]);
    });
  },

  getItems(orderId, cb) {
    const sql = 'SELECT oi.*, p.productName FROM order_items oi JOIN products p ON oi.productId = p.id WHERE oi.orderId = ?';
    connection.query(sql, [orderId], cb);
  },

  getByUserId(userId, cb) {
    const sql = 'SELECT * FROM orders WHERE userId = ? ORDER BY orderDate DESC';
    connection.query(sql, [userId], cb);
  }
};

module.exports = Order;
