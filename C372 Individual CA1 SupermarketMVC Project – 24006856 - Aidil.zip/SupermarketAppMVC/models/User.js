const connection = require('../db');

const User = {
  create(user, cb) {
    const sql = 'INSERT INTO users (username, email, password, address, contact, role) VALUES (?, ?, SHA1(?), ?, ?, ?)';
    connection.query(sql, [user.username, user.email, user.password, user.address, user.contact, user.role || 'user'], cb);
  },

  findByEmailAndPassword(email, password, cb) {
    const sql = 'SELECT * FROM users WHERE email = ? AND password = SHA1(?)';
    connection.query(sql, [email, password], cb);
  },

  getById(id, cb) {
    const sql = 'SELECT * FROM users WHERE id = ?';
    connection.query(sql, [id], (err, results) => {
      if (err) return cb(err);
      cb(null, results[0]);
    });
  },

  getAll(cb) {
    const sql = 'SELECT id, username, email, address, contact, role FROM users ORDER BY username ASC';
    connection.query(sql, cb);
  },

  update(id, user, cb) {
    const sql = 'UPDATE users SET username = ?, email = ?, address = ?, contact = ?, role = ? WHERE id = ?';
    connection.query(sql, [user.username, user.email, user.address, user.contact, user.role, id], cb);
  },

  delete(id, cb) {
    const sql = 'DELETE FROM users WHERE id = ?';
    connection.query(sql, [id], cb);
  }
};

module.exports = User;
