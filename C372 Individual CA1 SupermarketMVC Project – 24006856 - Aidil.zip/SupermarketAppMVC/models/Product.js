// ...existing code...
const db = require('../db');

const Product = {
  // get all products
  getAll(callback) {
    const sql = 'SELECT * FROM products';
    db.query(sql, (err, results) => {
      if (err) return callback(err);
      return callback(null, results);
    });
  },

  // get all products with optional price sorting
  getAllSorted(sortOrder, callback) {
    const direction = sortOrder === 'price_desc' ? 'DESC' : 'ASC';
    const sql = `SELECT * FROM products ORDER BY price ${direction}`;
    db.query(sql, (err, results) => {
      if (err) return callback(err);
      return callback(null, results);
    });
  },

  // get a product by ID
  getById(productId, callback) {
    const sql = 'SELECT * FROM products WHERE id = ?';
    db.query(sql, [productId], (err, results) => {
      if (err) return callback(err);
      return callback(null, results[0] || null);
    });
  },

  // add a new product
  // expects product fields: name, description, price, image
  add(product, callback) {
    const sql = 'INSERT INTO products (productName, description, price, image, quantity) VALUES (?, ?, ?, ?, ?)';
    const params = [
      product.name || null,
      product.description || null,
      product.price || null,
      product.image || null,
      product.quantity || 0
    ];
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      return callback(null, { insertId: result.insertId });
    });
  },

  // update an existing product by ID
  // expects product fields: name, description, price, image, quantity
  update(productId, product, callback) {
    // Build dynamic SQL to only update provided fields
    const updates = [];
    const params = [];
    
    if (product.name !== null && product.name !== undefined) {
      updates.push('productName = ?');
      params.push(product.name);
    }
    if (product.description !== null && product.description !== undefined) {
      updates.push('description = ?');
      params.push(product.description);
    }
    if (product.price !== null && product.price !== undefined) {
      updates.push('price = ?');
      params.push(product.price);
    }
    if (product.image !== null && product.image !== undefined) {
      updates.push('image = ?');
      params.push(product.image);
    }
    if (product.quantity !== null && product.quantity !== undefined) {
      updates.push('quantity = ?');
      params.push(product.quantity);
    }
    
    if (updates.length === 0) {
      return callback(new Error('No fields to update'));
    }
    
    const sql = `UPDATE products SET ${updates.join(', ')} WHERE id = ?`;
    params.push(productId);
    
    db.query(sql, params, (err, result) => {
      if (err) return callback(err);
      return callback(null, {
        affectedRows: result.affectedRows,
        changedRows: result.changedRows
      });
    });
  },

  // delete a product by ID
  delete(productId, callback) {
    const sql = 'DELETE FROM products WHERE id = ?';
    db.query(sql, [productId], (err, result) => {
      if (err) return callback(err);
      return callback(null, { affectedRows: result.affectedRows });
    });
  }
};

module.exports = Product;