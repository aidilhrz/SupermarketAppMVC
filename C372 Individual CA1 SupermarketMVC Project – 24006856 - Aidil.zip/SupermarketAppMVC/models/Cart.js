const db = require('../db');

// Cart model - uses database table cart_items
const Cart = {
  // Get all cart items for a user from database
  getByUserId(userId, callback) {
    const sql = `
      SELECT ci.*, p.productName, p.price, p.image 
      FROM cart_items ci
      JOIN products p ON ci.productId = p.id
      WHERE ci.userId = ?
    `;
    db.query(sql, [userId], (err, results) => {
      if (err) return callback(err);
      return callback(null, results);
    });
  },

  // Add item to cart in database
  addItem(userId, productId, quantity, callback) {
    const sql = `
      INSERT INTO cart_items (userId, productId, quantity)
      VALUES (?, ?, ?)
      ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
    `;
    db.query(sql, [userId, productId, quantity], (err, result) => {
      if (err) return callback(err);
      return callback(null, result);
    });
  },

  // Update cart item quantity
  updateQuantity(userId, productId, quantity, callback) {
    const sql = 'UPDATE cart_items SET quantity = ? WHERE userId = ? AND productId = ?';
    db.query(sql, [quantity, userId, productId], (err, result) => {
      if (err) return callback(err);
      return callback(null, result);
    });
  },

  // Remove item from cart
  removeItem(userId, productId, callback) {
    const sql = 'DELETE FROM cart_items WHERE userId = ? AND productId = ?';
    db.query(sql, [userId, productId], (err, result) => {
      if (err) return callback(err);
      return callback(null, result);
    });
  },

  // Clear all cart items for a user
  clearCart(userId, callback) {
    const sql = 'DELETE FROM cart_items WHERE userId = ?';
    db.query(sql, [userId], (err, result) => {
      if (err) return callback(err);
      return callback(null, result);
    });
  },

  // Calculate cart total
  calculateTotal(cartItems) {
    if (!Array.isArray(cartItems)) return 0;
    return cartItems.reduce((total, item) => {
      return total + (parseFloat(item.price) * parseInt(item.quantity));
    }, 0);
  }
};

module.exports = Cart;
