const db = require('./db');
const fs = require('fs');
const path = require('path');

const sqlFile = path.join(__dirname, 'create_cart_items_table.sql');
const sql = fs.readFileSync(sqlFile, 'utf8');

console.log('Creating cart_items table...');

db.query(sql, (err, result) => {
    if (err) {
        console.error('Error creating cart_items table:', err);
        process.exit(1);
    }
    
    console.log('✓ Cart_items table created successfully!');
    console.log('Migration completed.');
    
    // Close connection
    db.end();
});
