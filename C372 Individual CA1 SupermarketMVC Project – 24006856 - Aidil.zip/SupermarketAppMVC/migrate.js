const mysql = require('mysql2');
const fs = require('fs');
require('dotenv').config();

// Create connection
const connection = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

// Connect to database
connection.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
        process.exit(1);
    }
    console.log('✓ Connected to MySQL database');
});

// Read SQL file
const sql = fs.readFileSync('./create_tables.sql', 'utf8');

// Split by semicolon and execute each statement
const statements = sql.split(';').filter(stmt => stmt.trim());

let completed = 0;
let errors = [];

statements.forEach((statement, index) => {
    const stmt = statement.trim();
    if (stmt) {
        connection.query(stmt, (err, results) => {
            if (err) {
                console.error(`❌ Error executing statement ${index + 1}:`, err.message);
                errors.push(`Statement ${index + 1}: ${err.message}`);
            } else {
                console.log(`✓ Statement ${index + 1} executed successfully`);
            }
            completed++;

            // Close connection after all statements are executed
            if (completed === statements.length) {
                connection.end(() => {
                    console.log('\n✓ Database migration completed!');
                    if (errors.length > 0) {
                        console.log('\nErrors encountered:');
                        errors.forEach(err => console.log(`  - ${err}`));
                        process.exit(1);
                    } else {
                        console.log('All tables and indexes created successfully.');
                        process.exit(0);
                    }
                });
            }
        });
    }
});
