const User = require('../models/User');

const UserController = {
  // List all users (admin)
  getAll(req, res) {
    User.getAll((err, users) => {
      if (err) {
        console.error('Error fetching users:', err);
        req.flash('error', 'Failed to fetch users');
        return res.redirect('/inventory');
      }
      res.render('listUsers', { users: users, user: req.session.user });
    });
  },

  // Get user by ID for edit form
  getById(req, res) {
    const id = req.params.id;
    User.getById(id, (err, user) => {
      if (err) {
        console.error('Error fetching user:', err);
        req.flash('error', 'Failed to fetch user');
        return res.redirect('/list-users');
      }
      res.render('updateUser', {
        user: user,
        messages: req.flash('success'),
        errors: req.flash('error')
      });
    });
  },

  // Render add user form
  getAddForm(req, res) {
    res.render('addUser', {
      messages: req.flash('success'),
      errors: req.flash('error'),
      formData: req.flash('formData')[0]
    });
  },

  // Create new user (admin)
  create(req, res) {
    const { username, email, password, address, contact, role } = req.body;
    const newUser = { username, email, password, address, contact, role };

    User.create(newUser, (err, result) => {
      if (err) {
        console.error('Error creating user:', err);
        if (err.code === 'ER_DUP_ENTRY') {
          req.flash('error', 'Email already in use');
          req.flash('formData', req.body);
          return res.redirect('/add-user');
        }
        req.flash('error', 'Failed to create user');
        req.flash('formData', req.body);
        return res.redirect('/add-user');
      }
      req.flash('success', 'User created successfully');
      res.redirect('/list-users');
    });
  },

  // Update user (admin)
  update(req, res) {
    const { id, username, email, address, contact, role } = req.body;
    const updated = { username, email, address, contact, role };

    User.update(id, updated, (err, result) => {
      if (err) {
        console.error('Error updating user:', err);
        req.flash('error', 'Failed to update user');
        req.flash('formData', req.body);
        return res.redirect('/update-user/' + id);
      }
      req.flash('success', 'User updated successfully');
      res.redirect('/list-users');
    });
  },

  // Delete user (admin)
  delete(req, res) {
    const id = req.params.id;
    User.delete(id, (err) => {
      if (err) {
        console.error('Error deleting user:', err);
        req.flash('error', 'Failed to delete user');
        return res.redirect('/list-users');
      }
      req.flash('success', 'User deleted');
      res.redirect('/list-users');
    });
  },

  // Get user profile (current user)
  getProfile(req, res) {
    User.getById(req.session.user.id, (err, user) => {
      if (err) {
        req.flash('error', 'Failed to fetch profile');
        return res.redirect('/shopping');
      }
      res.render('profile', { user: user });
    });
  }
};

module.exports = UserController;
