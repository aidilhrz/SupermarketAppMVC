const Order = require('../models/Order');
const Cart = require('../models/Cart');

const OrderController = {
  // Render checkout page
  getCheckout(req, res) {
    const userId = req.session.user.id;

    Cart.getByUserId(userId, (err, cart) => {
      if (err) {
        console.error('Error fetching cart:', err);
        req.flash('error', 'Failed to load cart');
        return res.redirect('/cart');
      }

      if (cart.length === 0) {
        req.flash('error', 'Your cart is empty. Add items before checkout.');
        return res.redirect('/cart');
      }

      const total = Cart.calculateTotal(cart);

      res.render('checkout', {
        cart: cart,
        user: req.session.user,
        total: total.toFixed(2),
        messages: req.flash('error')
      });
    });
  },

  // Process order (create order and items)
  createOrder(req, res) {
    const { fullName, address, contact, paymentMethod } = req.body;
    const userId = req.session.user.id;

    Cart.getByUserId(userId, (err, cart) => {
      if (err) {
        console.error('Error fetching cart:', err);
        req.flash('error', 'Failed to load cart');
        return res.redirect('/cart');
      }

      if (cart.length === 0) {
        req.flash('error', 'Your cart is empty');
        return res.redirect('/cart');
      }

      const total = Cart.calculateTotal(cart);
      const orderDate = new Date();
      const orderStatus = 'pending';

      const orderData = {
        userId: userId,
        orderDate: orderDate,
        totalAmount: total,
        status: orderStatus
      };

      Order.create(orderData, (err, orderResult) => {
        if (err) {
          console.error('Error creating order:', err);
          req.flash('error', 'Failed to create order. Please try again.');
          return res.redirect('/checkout');
        }

        const orderId = orderResult.insertId;

        // Add order items
        Order.addItems(orderId, cart, (err) => {
          if (err) {
            console.error('Error adding order items:', err);
            req.flash('error', 'Failed to add items to order');
            return res.redirect('/checkout');
          }

          // Clear cart from database and redirect to confirmation
          Cart.clearCart(userId, (err) => {
            if (err) {
              console.error('Error clearing cart:', err);
              // Continue anyway - order is created
            }
            req.flash('success', 'Order placed successfully! Order ID: ' + orderId);
            res.redirect('/order-confirmation/' + orderId);
          });
        });
      });
    });
  },

  // Get order confirmation page
  getConfirmation(req, res) {
    const { orderId } = req.params;

    Order.getById(orderId, (err, order) => {
      if (err) {
        console.error('Error fetching order:', err);
        return res.status(500).send('Server error');
      }

      if (!order || order.userId !== req.session.user.id) {
        return res.status(404).send('Order not found');
      }

      order.totalAmount = parseFloat(order.totalAmount) || 0;

      Order.getItems(orderId, (err, items) => {
        if (err) {
          console.error('Error fetching order items:', err);
          return res.status(500).send('Server error');
        }

        items.forEach(item => {
          item.price = parseFloat(item.price) || 0;
        });

        res.render('orderConfirmation', {
          order: order,
          items: items,
          user: req.session.user,
          success: req.flash('success')
        });
      });
    });
  },

  // Get order history for user
  getHistory(req, res) {
    Order.getByUserId(req.session.user.id, (err, orders) => {
      if (err) {
        console.error('Error fetching orders:', err);
        req.flash('error', 'Failed to fetch order history');
        return res.redirect('/shopping');
      }

      orders.forEach(order => {
        order.totalAmount = parseFloat(order.totalAmount) || 0;
      });

      res.render('orderHistory', {
        orders: orders,
        user: req.session.user,
        messages: req.flash('error')
      });
    });
  },

  // Get order details (JSON or view)
  getOrderDetails(req, res) {
    const { orderId } = req.params;

    Order.getById(orderId, (err, order) => {
      if (err) {
        return res.status(500).json({ error: 'Server error' });
      }

      if (!order || order.userId !== req.session.user.id) {
        return res.status(404).json({ error: 'Order not found' });
      }

      Order.getItems(orderId, (err, items) => {
        if (err) {
          return res.status(500).json({ error: 'Server error' });
        }

        order.totalAmount = parseFloat(order.totalAmount) || 0;
        items.forEach(item => {
          item.price = parseFloat(item.price) || 0;
        });

        res.json({ order: order, items: items });
      });
    });
  }
};

module.exports = OrderController;
