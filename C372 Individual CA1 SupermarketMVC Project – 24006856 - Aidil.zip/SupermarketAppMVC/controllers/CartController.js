const Cart = require('../models/Cart');

const CartController = {
  // Get cart view
  getCart(req, res) {
    const userId = req.session.user.id;
    
    console.log('=== getCart called, userId:', userId);
    
    Cart.getByUserId(userId, (err, cartItems) => {
      if (err) {
        console.error('=== ERROR fetching cart ===', err);
        req.flash('error', 'Failed to load cart');
        return res.redirect('/shopping');
      }
      
      console.log('Cart items fetched:', cartItems ? cartItems.length : 0);
      
      res.render('cart', {
        cart: cartItems || [],
        user: req.session.user,
        success: req.flash('success'),
        error: req.flash('error')
      });
    });
  },

  // Add item to cart
  addToCart(req, res) {
    const productId = parseInt(req.params.id);
    const quantity = parseInt(req.body.quantity) || 1;
    const userId = req.session.user.id;

    // First, get the product to check stock
    const Product = require('../models/Product');
    Product.getById(productId, (err, product) => {
      if (err || !product) {
        console.error('Error fetching product:', err);
        req.flash('error', 'Product not found');
        return res.redirect('/shopping');
      }

      // Check if requested quantity exceeds available stock
      if (quantity > product.quantity) {
        req.flash('error', `Cannot add ${quantity} items. Only ${product.quantity} available in stock.`);
        return res.redirect('/shopping');
      }

      Cart.addItem(userId, productId, quantity, (err, result) => {
        if (err) {
          console.error('Error adding to cart:', err);
          req.flash('error', 'Failed to add item to cart');
          return res.redirect('/shopping');
        }

        req.flash('success', 'Item added to cart');
        res.redirect('/cart');
      });
    });
  },

  // Update quantity in cart
  updateQuantity(req, res) {
    const { productId, quantity } = req.body;
    const qty = parseInt(quantity) || 1;
    const userId = req.session.user.id;

    console.log('Update quantity request:', { productId, quantity, qty, userId });

    if (qty < 1) {
      req.flash('error', 'Quantity must be at least 1');
      return res.redirect('/cart');
    }

    // First, get current cart to check if quantity actually changed
    Cart.getByUserId(userId, (err, cartItems) => {
      if (err) {
        console.error('Error fetching cart:', err);
        req.flash('error', 'Failed to update quantity');
        return res.redirect('/cart');
      }

      const currentItem = cartItems.find(item => item.productId === parseInt(productId));
      const currentQty = currentItem ? currentItem.quantity : 0;

      console.log('Current item:', currentItem);
      console.log('Current quantity:', currentQty, 'New quantity:', qty);

      // Only update if quantity is different
      if (currentQty === qty) {
        // No change, redirect without message
        console.log('No change in quantity');
        return res.redirect('/cart');
      }

      Cart.updateQuantity(userId, parseInt(productId), qty, (err, result) => {
        if (err) {
          console.error('Error updating cart:', err);
          req.flash('error', 'Failed to update quantity');
          return res.redirect('/cart');
        }

        console.log('Update result:', result);
        req.flash('success', 'Quantity updated');
        res.redirect('/cart');
      });
    });
  },

  // Remove item from cart
  removeItem(req, res) {
    const productId = parseInt(req.params.productId);
    const userId = req.session.user.id;

    Cart.removeItem(userId, productId, (err, result) => {
      if (err) {
        console.error('Error removing from cart:', err);
        req.flash('error', 'Failed to remove item');
        return res.redirect('/cart');
      }

      req.flash('success', 'Item removed from cart');
      res.redirect('/cart');
    });
  },

  // Clear entire cart
  clearCart(req, res) {
    const userId = req.session.user.id;

    Cart.clearCart(userId, (err, result) => {
      if (err) {
        console.error('Error clearing cart:', err);
        req.flash('error', 'Failed to clear cart');
        return res.redirect('/cart');
      }

      req.flash('success', 'Cart has been cleared');
      res.redirect('/cart');
    });
  },

  // Get cart total
  getCartTotal(req, res) {
    const userId = req.session.user.id;
    
    Cart.getByUserId(userId, (err, cartItems) => {
      if (err) {
        return res.json({ total: '0.00', itemCount: 0 });
      }
      
      const total = Cart.calculateTotal(cartItems);
      res.json({ total: total.toFixed(2), itemCount: cartItems.length });
    });
  }
};

module.exports = CartController;
