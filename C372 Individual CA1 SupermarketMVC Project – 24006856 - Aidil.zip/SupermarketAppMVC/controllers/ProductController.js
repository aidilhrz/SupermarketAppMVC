const Product = require('../models/Product');

const ProductController = {
  // list all products
  list(req, res) {
    const isAdmin = req.session.user && req.session.user.role === 'admin';
    const sort = req.query && req.query.sort;
    const allowPriceSort = sort === 'price_asc' || sort === 'price_desc';
    const fetchProducts = allowPriceSort
      ? (cb) => Product.getAllSorted(sort, cb)
      : Product.getAll;

    fetchProducts((err, products) => {
      if (err) {
        console.error('Error fetching products:', err);
        return res.status(500).send('Server error while retrieving products.');
      }
      // Render different views depending on user role:
      // - admin -> inventory view
      // - regular user -> shopping view
      const view = (req.session.user && req.session.user.role === 'admin') ? 'inventory' : 'shopping';
      // include flash messages to templates to avoid undefined errors
      const renderData = {
        products: products,
        user: req.session.user,
        messages: req.flash('success'),
        errors: req.flash('error'),
        currentSort: allowPriceSort ? sort : null
      };
      if (res.render) return res.render(view, renderData);
      return res.json(products);
    });
  },

  // get a single supermarket by ID
  getById(req, res) {
    const id = req.params.id;
    Product.getById(id, (err, product) => {
      if (err) {
        console.error(`Error fetching products ${id}:`, err);
        return res.status(500).send('Server error while retrieving products.');
      }
      if (!product) return res.status(404).send('Product not found.');
      // render product view (fallback to JSON)
      if (res.render) return res.render('product', { product: product, user: req.session.user });
      return res.json(product);
    });
  },

  // add a new product (expects form data in req.body, optional file in req.file)
  add(req, res) {
    const product = {
      name: req.body.name || null,
      description: req.body.description || null,
      price: req.body.price || null,
      quantity: typeof req.body.quantity !== 'undefined' ? parseInt(req.body.quantity) : 0,
      image: (req.file && req.file.filename) || req.body.image || null
    };

    Product.add(product, (err, result) => {
      if (err) {
        console.error('Error adding product:', err);
        req.flash('error', 'Failed to add product');
        return res.redirect('/inventory');
      }
      req.flash('success', 'Product added');
      if (res.redirect) return res.redirect('/inventory');
      return res.json({ insertId: result.insertId });
    });
  },

  // update an existing product by ID
  update(req, res) {
    const id = req.params.id;
    const product = {
      name: req.body.name || null,
      description: req.body.description || null,
      price: typeof req.body.price !== 'undefined' ? parseFloat(req.body.price) : null,
      quantity: typeof req.body.quantity !== 'undefined' ? parseInt(req.body.quantity) : null,
      // Preserve existing image when no new upload is provided
      image: (req.file && req.file.filename) || req.body.existingImage || null
    };

    console.log('Updating product ID:', id);
    console.log('Product data:', product);

    Product.update(id, product, (err, result) => {
      if (err) {
        console.error(`Error updating product ${id}:`, err);
        req.flash('error', 'Failed to update product: ' + err.message);
        return res.redirect('/inventory');
      }
      if (result.affectedRows === 0) {
        req.flash('error', 'Product not found');
        return res.redirect('/inventory');
      }
      req.flash('success', 'Product updated successfully');
      if (res.redirect) return res.redirect('/inventory');
      return res.json({ affectedRows: result.affectedRows, changedRows: result.changedRows });
    });
  },

  // delete a product by ID
  delete(req, res) {
    const id = req.params.id;
    Product.delete(id, (err, result) => {
      if (err) {
        console.error(`Error deleting product ${id}:`, err);
        return res.status(500).send('Server error while deleting product.');
      }
      if (result.affectedRows === 0) return res.status(404).send('Product not found.');
      if (res.redirect) return res.redirect('/');
      return res.json({ affectedRows: result.affectedRows });
    });
  }
};

module.exports = ProductController;
