const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const multer = require('multer');
const path = require('path');
const app = express();

// Use shared DB connection from db.js (remove direct connection creation here)
const connection = require('./db');

// Import controllers
const productController = require('./controllers/ProductController');
const cartController = require('./controllers/CartController');
const orderController = require('./controllers/OrderController');
const userController = require('./controllers/UserController');

// Set up multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, 'public', 'images')); // Directory to save uploaded files
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

// Set up view engine
app.set('view engine', 'ejs');
// enable static files
app.use(express.static('public'));
// enable form processing
app.use(express.urlencoded({
    extended: false
}));

// Session Middleware
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true,
    // Session expires after 1 week of inactivity
    cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }
}));

app.use(flash());

// Import models and validators
const User = require('./models/User');

// Validation middleware for admin creating users
const validateUserCreate = (req, res, next) => {
    const { username, email, password, address, contact, role } = req.body;
    const errors = [];
    if (!username || username.trim().length < 3) errors.push('Username must be at least 3 characters');
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) errors.push('Valid email is required');
    if (!password || password.length < 6) errors.push('Password must be at least 6 characters');
    if (contact && !/^[0-9+\-\s()]{7,20}$/.test(contact)) errors.push('Contact must be a valid phone number');
    if (role && !['user','admin'].includes(role)) errors.push('Invalid role');

    if (errors.length) {
        req.flash('error', errors);
        req.flash('formData', req.body);
        return res.redirect('/add-user');
    }
    next();
};

// Validation middleware for admin updating users
const validateUserUpdate = (req, res, next) => {
    const { id, username, email, address, contact, role } = req.body;
    const errors = [];
    if (!id) errors.push('Missing user id');
    if (!username || username.trim().length < 3) errors.push('Username must be at least 3 characters');
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) errors.push('Valid email is required');
    if (contact && !/^[0-9+\-\s()]{7,20}$/.test(contact)) errors.push('Contact must be a valid phone number');
    if (role && !['user','admin'].includes(role)) errors.push('Invalid role');

    if (errors.length) {
        req.flash('error', errors);
        req.flash('formData', req.body);
        return res.redirect('/update-user/' + (id || ''));
    }
    next();
};

// Middleware to check if user is logged in
const checkAuthenticated = (req, res, next) => {
    if (req.session.user) {
        return next();
    } else {
        req.flash('error', 'Please log in to view this resource');
        res.redirect('/login');
    }
};

// Middleware to check if user is admin
const checkAdmin = (req, res, next) => {
    if (req.session.user && req.session.user.role === 'admin') {
        return next();
    } else {
        req.flash('error', 'Access denied');
        res.redirect('/shopping');
    }
};

// Middleware for form validation
const validateRegistration = (req, res, next) => {
    const { username, email, password, address, contact } = req.body;

    if (!username || !email || !password || !address || !contact) {
        return res.status(400).send('All fields are required.');
    }

    if (password.length < 6) {
        req.flash('error', 'Password should be at least 6 or more characters long');
        req.flash('formData', req.body);
        return res.redirect('/register');
    }
    next();
};

// Define routes
app.get('/',  (req, res) => {
    res.render('index', {user: req.session.user} );
});

// List all products for inventory (admin) using controller
app.get('/inventory', checkAuthenticated, checkAdmin, (req, res) => {
    productController.list(req, res);
});

// Admin dashboard
app.get('/admin-dashboard', checkAuthenticated, checkAdmin, (req, res) => {
    res.render('adminDashboard', { user: req.session.user });
});

// Registration / Login routes (still use connection for users)
app.get('/register', (req, res) => {
    res.render('register', { messages: req.flash('error'), formData: req.flash('formData')[0] });
});

app.post('/register', validateRegistration, (req, res) => {
    const { username, email, password, address, contact } = req.body;

    // Force role to 'user' to prevent self-registration as admin
    const role = 'user';

    const sql = 'INSERT INTO users (username, email, password, address, contact, role) VALUES (?, ?, SHA1(?), ?, ?, ?)';
    connection.query(sql, [username, email, password, address, contact, role], (err, result) => {
        if (err) {
            throw err;
        }
        req.flash('success', 'Registration successful! Please log in.');
        res.redirect('/login');
    });
});

app.get('/login', (req, res) => {
    res.render('login', { messages: req.flash('success'), errors: req.flash('error') });
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;

    // Validate email and password
    if (!email || !password) {
        req.flash('error', 'All fields are required.');
        return res.redirect('/login');
    }

    const sql = 'SELECT * FROM users WHERE email = ? AND password = SHA1(?)';
    connection.query(sql, [email, password], (err, results) => {
        if (err) {
            throw err;
        }

        if (results.length > 0) {
            // Successful login
            req.session.user = results[0];
            req.flash('success', 'Login successful!');
            if(req.session.user.role == 'user')
                res.redirect('/shopping');
            else
                res.redirect('/admin-dashboard');
        } else {
            // Invalid credentials
            req.flash('error', 'Invalid email or password.');
            res.redirect('/login');
        }
    });
});

// List products for shopping (user) using controller
app.get('/shopping', checkAuthenticated, (req, res) => {
    productController.list(req, res);
});

// Add to cart - use CartController
app.post('/add-to-cart/:id', checkAuthenticated, (req, res) => {
    cartController.addToCart(req, res);
});

app.get('/cart', checkAuthenticated, (req, res) => {
    cartController.getCart(req, res);
});

// Update cart item quantity
app.post('/update-cart-qty', checkAuthenticated, (req, res) => {
    cartController.updateQuantity(req, res);
});

// Remove item from cart
app.get('/remove-from-cart/:productId', checkAuthenticated, (req, res) => {
    cartController.removeItem(req, res);
});

// Clear entire cart
app.get('/clear-cart', checkAuthenticated, (req, res) => {
    cartController.clearCart(req, res);
});

// Checkout page - use OrderController
app.get('/checkout', checkAuthenticated, (req, res) => {
    orderController.getCheckout(req, res);
});

// Process order - use OrderController
app.post('/process-order', checkAuthenticated, (req, res) => {
    orderController.createOrder(req, res);
});

// Order confirmation page - use OrderController
app.get('/order-confirmation/:orderId', checkAuthenticated, (req, res) => {
    orderController.getConfirmation(req, res);
});

// Order history page - use OrderController
app.get('/order-history', checkAuthenticated, (req, res) => {
    orderController.getHistory(req, res);
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

// Get a single product by ID using controller
app.get('/product/:id', checkAuthenticated, (req, res) => {
    productController.getById(req, res);
});

// Render add product form
app.get('/addProduct', checkAuthenticated, checkAdmin, (req, res) => {
    res.render('addProduct', {
        user: req.session.user,
        messages: req.flash('success'),
        errors: req.flash('error'),
        formData: req.flash('formData')[0]
    });
});

// Handle add product (file upload) using controller
app.post('/addProduct', checkAuthenticated, checkAdmin, upload.single('image'), (req, res) => {
    productController.add(req, res);
});

// Render update product form - use controller to fetch product
app.get('/updateProduct/:id', checkAuthenticated, checkAdmin, (req, res) => {
    productController.getById(req, res);
});

// Handle update product (file upload) using controller
app.post('/updateProduct/:id', checkAuthenticated, checkAdmin, upload.single('image'), (req, res) => {
    productController.update(req, res);
});

// Delete product using controller
app.get('/deleteProduct/:id', checkAuthenticated, checkAdmin, (req, res) => {
    productController.delete(req, res);
});

// User management - admin routes
// List users (admin) - use UserController
app.get('/list-users', checkAuthenticated, checkAdmin, (req, res) => {
    userController.getAll(req, res);
});

// Render add user form
app.get('/add-user', checkAuthenticated, checkAdmin, (req, res) => {
    userController.getAddForm(req, res);
});

// Handle add user (admin) - use UserController
app.post('/add-user', checkAuthenticated, checkAdmin, validateUserCreate, (req, res) => {
    userController.create(req, res);
});

// Render update user form
app.get('/update-user/:id', checkAuthenticated, checkAdmin, (req, res) => {
    userController.getById(req, res);
});

// Handle update user (admin) - use UserController
app.post('/update-user', checkAuthenticated, checkAdmin, validateUserUpdate, (req, res) => {
    userController.update(req, res);
});

// Delete user (admin) - use UserController
app.get('/delete-user/:id', checkAuthenticated, checkAdmin, (req, res) => {
    userController.delete(req, res);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
